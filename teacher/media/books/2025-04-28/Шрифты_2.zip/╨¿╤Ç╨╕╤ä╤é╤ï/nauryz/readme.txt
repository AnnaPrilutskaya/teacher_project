FREE FONT / Latin / Cyr / Kz 

https://www.behance.net/gallery/196325487/FREE-FONT-NAURYZREDKEDS